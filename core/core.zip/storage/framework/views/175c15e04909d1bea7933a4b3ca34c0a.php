
<?php
$blogContent = getContent('blog.content', true);
$blogs       = getContent('blog.element');
?>

<?php if($blogContent): ?>
<div class="ongoing-campaign section-bg">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-12">
                <span class="ongoing-campaign__title"> <?php echo e(__(@$blogContent->data_values->heading)); ?> </span>
            </div>
        </div>
        <div class="swiper mySwiper">
            <div class="swiper-wrapper">
                <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="swiper-slide">
                        <a href="<?php echo e(route('blog.details', @$blog->slug)); ?>"
                            class="testimonials-card">
                            <img src="<?php echo e(getImage('assets/images/frontend/blog/thumb_' . @$blog->data_values->image, '300x150')); ?>">
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>
<?php /**PATH /home/fmllkckxhosting/domains/cow.kuratajr.click/core/resources/views/templates/basic/sections/blog.blade.php ENDPATH**/ ?>