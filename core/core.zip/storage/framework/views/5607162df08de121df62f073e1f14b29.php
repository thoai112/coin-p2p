<?php
    $content  = getContent('how_to_invest.content',true);
    $elements = getContent('how_to_invest.element',orderById:true);
?>
<section class="invest-section py-120">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="section-heading style-left">
                   <h2 class="section-heading__title"><?php echo e(__(@$content->data_values->heading)); ?></h2>
                   <p class="section-heading__desc"><?php echo e(__(@$content->data_values->subheading)); ?></p>
                </div>
            </div>
        </div>
        <div class="row gy-4 align-items-center">
            <div class="col-lg-6 pe-lg-5">
              <ul class="invest-item">
                <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <div class="invest-item__content">
                        <span class="invest-item__style"> <?php echo e($loop->iteration); ?> </span>
                        <h4 class="invest-item__title"><?php echo e(__(@$element->data_values->heading)); ?></h4>
                        <p class="invest-item__desc"><?php echo e(__(@$element->data_values->subheading)); ?> </p>
                    </div>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
              <div class="invest__button">
                <a href="<?php echo e(@$content->data_values->button_link); ?>" class="btn btn--base"> <?php echo e(__(@$content->data_values->button_text)); ?> </a>
              </div>
            </div>
            <div class="col-lg-6 ps-lg-5">
                <div class="invest-thumb l-mood">
                    <img src="<?php echo e(getImage('assets/images/frontend/how_to_invest/'.@$content->data_values->image_light,'630x470')); ?>" >
                </div>
                <div class="invest-thumb d-mood">
                    <img src="<?php echo e(getImage('assets/images/frontend/how_to_invest/'.@$content->data_values->image_dark,'630x470')); ?>" >
                </div>
            </div>
        </div>
    </div>
</section>
<?php /**PATH /home/fmllkckxhosting/domains/cow.kuratajr.click/core/resources/views/templates/basic/sections/how_to_invest.blade.php ENDPATH**/ ?>