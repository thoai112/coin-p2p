<div class = "py-120 table-section ">
    <div class="table-section__shape light-mood">
        <img src="<?php echo e(asset($activeTemplateTrue.'images/shapes/table-1.png')); ?>">
    </div>
    <div class="table-section__shape dark-mood style">
        <img src="<?php echo e(asset($activeTemplateTrue.'images/shapes/table-12.png')); ?>">
    </div>
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <?php if (isset($component)) { $__componentOriginalb4d7a76f273e1ce6275894d99e164dac = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb4d7a76f273e1ce6275894d99e164dac = $attributes; } ?>
<?php $component = App\View\Components\FlexibleView::resolve(['view' => $activeTemplate.'sections.coin_pair_list','meta' => ['from_section' => true ]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flexible-view'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\FlexibleView::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb4d7a76f273e1ce6275894d99e164dac)): ?>
<?php $attributes = $__attributesOriginalb4d7a76f273e1ce6275894d99e164dac; ?>
<?php unset($__attributesOriginalb4d7a76f273e1ce6275894d99e164dac); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb4d7a76f273e1ce6275894d99e164dac)): ?>
<?php $component = $__componentOriginalb4d7a76f273e1ce6275894d99e164dac; ?>
<?php unset($__componentOriginalb4d7a76f273e1ce6275894d99e164dac); ?>
<?php endif; ?>
            </div>
        </div>
    </div>
</div>



<?php /**PATH /home/fmllkckxhosting/domains/cow.kuratajr.click/core/resources/views/templates/basic/sections/coin_pair.blade.php ENDPATH**/ ?>