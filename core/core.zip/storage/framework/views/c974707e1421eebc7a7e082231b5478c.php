<header class="header" id="header">
    <div class="container">
        <nav class="navbar navbar-expand-lg navbar-light">
            <a class="navbar-brand logo" href="<?php echo e(route('home')); ?>">
                <img src="<?php echo e(siteLogo()); ?>">
            </a>
            <button class="navbar-toggler header-button" type="button" data-bs-toggle="collapse"
                data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                aria-label="Toggle navigation">
                <span id="hiddenNav"><i class="las la-bars"></i></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav nav-menu me-auto align-items-lg-center flex-wrap">
                    <li class="nav-item d-block d-lg-none">
                        <?php if(gs("multi_language")): ?>
                            <?php
                                $langDetails = $languages->where('code', config('app.locale'))->first();
                            ?>
                            <div class="top-button d-flex flex-wrap justify-content-between align-items-center">
                                <div class="custom--dropdown">
                                    <div class="custom--dropdown__selected dropdown-list__item">
                                        <div class="thumb">
                                            <img
                                                src="<?php echo e(getImage(getFilePath('language') . '/' . @$langDetails->flag, getFileSize('language'))); ?>">
                                        </div>
                                        <span class="text"><?php echo e(__(@$langDetails->name)); ?></span>
                                    </div>
                                    <ul class="dropdown-list">
                                        <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li class="dropdown-list__item change-lang "
                                                data-code="<?php echo e(@$language->code); ?>">
                                                <div class="thumb">
                                                    <img
                                                        src="<?php echo e(getImage(getFilePath('language') . '/' . @$language->flag, getFileSize('language'))); ?>">
                                                </div>
                                                <span class="text"><?php echo e(__(@$language->name)); ?></span>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                                <ul class="login-registration-list d-flex flex-wrap align-items-center">
                                    <?php if(auth()->guard()->guest()): ?>
                                        <li class="login-registration-list__item">
                                            <a href="<?php echo e(route('user.login')); ?>" class="sign-in "><?php echo app('translator')->get('Login'); ?></a>
                                        </li>
                                        <li class="login-registration-list__item">
                                            <a href="<?php echo e(route('user.register')); ?>"
                                                class="btn btn--base btn--sm "><?php echo app('translator')->get('Sign up'); ?> </a>
                                        </li>
                                    <?php else: ?>
                                        <li class="login-registration-list__item">
                                            <a href="<?php echo e(route('user.home')); ?>"
                                                class="btn btn--base btn--sm"><?php echo app('translator')->get('Dashboard'); ?></a>
                                        </li>
                                        <li class="login-registration-list__item">
                                            <a href="<?php echo e(route('user.logout')); ?>" class="sign-in"><?php echo app('translator')->get('Logout'); ?></a>
                                        </li>
                                    <?php endif; ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('market')); ?>"><?php echo app('translator')->get('Market'); ?></a>
                        
                    </li>

                    <li class="nav-item has-mega-menu">
                        <a class="nav-link" href="javascript:void(0)"><?php echo app('translator')->get('Trade'); ?></a>
                        <div class="mega-menu">
                            <div class="mega-menu__inner">
                                <ul class="mega-menu-list">
                                    <li class="mega-menu-list__item mega-item-bg1">
                                        <a href="<?php echo e(route('trade')); ?>" class="mega-menu-list__link">
                                            <div class="mega-menu-list__content">
                                                <span class="mega-menu-list__title"><?php echo app('translator')->get('SPOT'); ?></span>
                                                <p class="mega-menu-list__desc"><?php echo app('translator')->get('Trade smartly with necessary Spot market tools.'); ?></p>
                                            </div>
                                            <span class="mega-menu-list__icon">
                                                <img class="fit-image" src="<?php echo e(getImage('assets/images/extra_images/bar-chart.png',null)); ?>" >
                                            </span>
                                        </a>
                                    </li>
                                    <li class="mega-menu-list__item mega-item-bg2">
                                        <a href="<?php echo e(route('p2p')); ?>" class="mega-menu-list__link">
                                            <div class="mega-menu-list__content">
                                                <span class="mega-menu-list__title"><?php echo app('translator')->get('P2P'); ?></span>
                                                <p class="mega-menu-list__desc"><?php echo app('translator')->get('Buy & sell crypto with your preferred payment methods.'); ?></p>
                                            </div>
                                            <span class="mega-menu-list__icon">
                                                <img class="fit-image" src="<?php echo e(getImage('assets/images/extra_images/p2p.png',null)); ?>">
                                            </span>
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('crypto_currencies')); ?>"><?php echo app('translator')->get('Crypto Currency'); ?></a>
                    </li>
                    <?php
                        $pages = App\Models\Page::where('is_default', Status::NO)->where('tempname', $activeTemplate)->get();
                    ?>
                    <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('pages', ['slug' => $item->slug])); ?>">
                                <?php echo e(__($item->name)); ?>

                            </a>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('contact')); ?>"> <?php echo app('translator')->get('Contact'); ?> </a>
                    </li>
                </ul>
            </div>
            <ul class="header-right d-lg-block d-none">
                <li class="nav-item">
                    <div class="top-button d-flex flex-wrap justify-content-between align-items-center">
                        <?php if(gs('multi_language')): ?>
                            <div class="custom--dropdown">
                                <div class="custom--dropdown__selected dropdown-list__item">
                                    <div class="thumb">
                                        <img
                                            src="<?php echo e(getImage(getFilePath('language') . '/' . @$langDetails->flag, getFileSize('language'))); ?>">
                                    </div>
                                    <span class="text"><?php echo e(__(@$langDetails->name)); ?></span>
                                </div>
                                <ul class="dropdown-list">
                                    <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="dropdown-list__item change-lang "
                                            data-code="<?php echo e(@$language->code); ?>">
                                            <div class="thumb">
                                                <img
                                                    src="<?php echo e(getImage(getFilePath('language') . '/' . @$language->flag, getFileSize('language'))); ?>">
                                            </div>
                                            <span class="text"><?php echo e(__(@$language->name)); ?></span>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                        <ul class="login-registration-list d-flex flex-wrap align-items-center">
                            <?php if(auth()->guard()->guest()): ?>
                                <li class="login-registration-list__item">
                                    <a href="<?php echo e(route('user.login')); ?>" class="sign-in"><?php echo app('translator')->get('Login'); ?></a>
                                </li>
                                <li class="login-registration-list__item">
                                    <a href="<?php echo e(route('user.register')); ?>"
                                        class="btn btn--base btn--sm"><?php echo app('translator')->get('Sign up'); ?> </a>

                                </li>
                            <?php else: ?>
                                <li class="login-registration-list__item">
                                    <a href="<?php echo e(route('user.home')); ?>"
                                        class="btn btn--base btn--sm"><?php echo app('translator')->get('Dashboard'); ?></a>
                                </li>
                                <li class="login-registration-list__item">
                                    <a href="<?php echo e(route('user.logout')); ?>" class="sign-in"><?php echo app('translator')->get('Logout'); ?></a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </div>
                </li>
            </ul>
            <?php if(!request()->routeIs('trade')): ?>
                <div class="theme-switch-wrapper">
                    <label class="theme-switch" for="checkbox">
                        <input type="checkbox" class="d-none" id="checkbox">
                        <span class="slider">
                            <i class="las la-sun"></i>
                        </span>
                    </label>
                </div>
            <?php endif; ?>
        </nav>
    </div>
</header>
<?php /**PATH /home/fmllkckxhosting/domains/cow.kuratajr.click/core/resources/views/templates/basic/partials/header.blade.php ENDPATH**/ ?>