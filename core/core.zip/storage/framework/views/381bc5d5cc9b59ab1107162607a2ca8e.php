
<?php
    $content  = getContent('product.content',true);
    $elements = getContent('product.element',orderById:true);
?>

<div class="product-section py-120">
    <div class="product-section__shape">
        <img src="<?php echo e(asset($activeTemplateTrue . 'images/shapes/bg.png')); ?>">
    </div>
    <div class="container">
        <div class="row gy-4 justify-content-center align-items-center">
            <div class="col-lg-6 pe-lg-5">
                <div class="section-heading style-left">
                    <h2 class="section-heading__title"><?php echo e(__(@$content->data_values->heading)); ?> </h2>
                    <p class="section-heading__desc"> <?php echo e(__(@$content->data_values->subheading)); ?> </p>
                  </div>
                <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="product-item">
                    <span class="product-item__icon">
                        <?php echo @$element->data_values->icon; ?>
                    </span>
                    <div class="product-item__content">
                        <h4 class="product-item__title"> <?php echo e(__(@$element->data_values->heading)); ?></h4>
                        <p class="product-item__desc"> <?php echo e(__(@$element->data_values->subheading)); ?> </p>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="col-lg-6 ps-lg-5">
                <div class="product-thumb l-mood">
                    <img src="<?php echo e(getImage('assets/images/frontend/product/'.@$content->data_values->image_light,'630x470')); ?>" >
                </div>
                <div class="product-thumb d-mood">
                    <img src="<?php echo e(getImage('assets/images/frontend/product/'.@$content->data_values->image_light,'630x470')); ?>" >
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH /home/fmllkckxhosting/domains/cow.kuratajr.click/core/resources/views/templates/basic/sections/product.blade.php ENDPATH**/ ?>